package programsPackages;

public class main  {

    public static void main(String[] args) {

        gui okno = new gui(800,600);
        okno.textarea(50,300);
        okno.gridpane();

    }
}
