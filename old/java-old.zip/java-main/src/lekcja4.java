import java.util.Random;

public class lekcja4 {

   public int oblicz(int liczba) {

        Random rx = new Random();
        int los = rx.nextInt(10) +1;

        if (liczba>0) {

            if (liczba>los) {
                liczba = oblicz(liczba - 1);
                return liczba ;
            }

            else if (liczba<los || liczba!=0)
                return liczba;
        }

        return 0;
    }


    public static void main (String[] args ) { int x = new lekcja4().oblicz(10);

    System.out.println(x);

   }

}