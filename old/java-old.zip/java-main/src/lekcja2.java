
public class lekcja2 {

    private int oblicz(int liczba1 ,int liczba2) { int test =1;

     if (liczba1 <10 && liczba2>10 && test >0) {

         int suma = liczba1 + liczba2;
         return suma;
      }
        else {
               int suma = 0;
               return suma;
         }
      }

     private boolean logic(boolean wynik) {

        boolean a =true;
        boolean b =false;
        boolean c =true;

        if (wynik!=a && wynik!=b || c!=b) {

                 Boolean suma;
                 suma = wynik;
                 return suma;
        }

        return false;
    }


          public static void main(String[] args) {
          System.out.println(new lekcja2().oblicz(4,12));
          System.out.println(new lekcja2().logic(false));

    }


}








