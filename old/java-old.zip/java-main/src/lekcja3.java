public class lekcja3 {
// sprawdz liczbę
    public int wylicz(int liczba) {

        if (liczba % 2 == 0) {
            return liczba;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {

        lekcja3 wynik = new lekcja3();
        int ex = wynik.wylicz(0);

        switch (ex) {

            case 0:
                System.out.println("błąd");
                break;
                default:
                   System.out.println("brawo to liczba parzysta ");

        }

    }

}









