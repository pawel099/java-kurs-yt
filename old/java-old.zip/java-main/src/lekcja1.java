
import java.util.Random;
import java.util.Scanner;

public class lekcja1 {

    public static void main(String[] args) {
         int los;
         int odp;
         int index=0;

         Scanner scanner = new Scanner(System.in);
         Random rmd = new Random();
         los = rmd.nextInt(10)+1;

         do {
                index++;
                odp = scanner.nextInt();

                if (odp>los )  {
                 System.out.println("wylosowana liczba jest mniejsza ");
                }

                else if (odp<los )  {
                   System.out.println("wylosowana liczba jest wieksza");
                }

                else {
                 System.out.println("brawo odgadłeś za " + index + "razem");
                }

           }  while (odp!=los);

        }
     }



