import java.util.Scanner;
// lista imion
public class kurs {

    public String lista() {

        Scanner scanner = new Scanner(System.in);
        String wynik = scanner.nextLine();

        String[] listaimion = new String[5];

        listaimion[0] = "pawel";
        listaimion[1] = "anna";
        listaimion[2] = "michal";
        listaimion[3] = "radosław";
        listaimion[4] = "jan";

        for (int index = 0; index < listaimion.length; index++) {

            if (wynik.equals(listaimion[index])) {

                String e = listaimion[index];
                return e;
            }
        }
        return "nie odnaleziono użytkownika";
    }


    public static void main (String[] args) {

        kurs kurs = new kurs();
        System.out.println(kurs.lista());
    }
 }








