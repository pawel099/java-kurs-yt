package javaGuiInterface;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;

import java.util.Scanner;

public class files {

    public static void main (String[] args) throws IOException {

        File plik = new File("plik.txt");

        if (!plik.exists()) {
            System.out.println("utworzono plik");

            try {
                plik.createNewFile();

            } catch (Exception e) {
                System.out.println(e.getMessage());

            }
        }

        if (plik.canWrite()) {

            try {


                FileWriter odczyt = new FileWriter(plik,true);
                Formatter fm = new Formatter(odczyt);
                Scanner scfile = new Scanner(plik);

                Scanner scanner = new Scanner(System.in);
                System.out.println("podaj dane do pliku");
                String text = scanner.nextLine();


                fm.format("%s \r\n",text);
                System.out.println("zapisano");
                odczyt.close();
                fm.close();


                while (scfile.hasNextLine()) {
                    System.out.println(scfile.nextLine());

                }

            }

            catch (Exception e) {

                System.out.println(e.getMessage());

            }

        }


        }

    }
