package javaTestApplication;

import java.util.Scanner;

public class test {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int dane = scanner.nextInt();

        if (dane % 2 != 0) {
            System.out.println(" to nie jest liczba parzysta");

        } else {
            System.out.println("brawo ! liczba parzysta");

        }
    }
}


