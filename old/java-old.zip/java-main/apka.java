package javaTestApplication;
import java.util.Scanner;

public class apka {

    protected String errs = "";
    protected String imie = "";


    private String apka() {

        String[] lista = new String[5];

        lista[0] = "pawel";
        lista[1] = "anna";
        lista[2] = "michal";
        lista[3] = "jan";
        lista[4] = "tomasz";

        int index = 0;

        Scanner scanner = new Scanner(System.in);
        String dane = scanner.nextLine();

        while (index < lista.length) {

            if (dane.equals(lista[index])) {
                return this.imie = lista[index];

            } else {
                this.errs = "nie odnaleziono uzytkownika";
            }

            index++;

        }
           return this.errs;
    }


        public static void main(String[] args) {

        apka apk = new apka();
        System.out.println(apk.apka());

    }

}