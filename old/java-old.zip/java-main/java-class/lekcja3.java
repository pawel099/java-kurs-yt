package com.example.basic;

public class lekcja3 {

    public static void main(String[] args) {

        int[] tabelka = new int[5];

        tabelka[0]=1;
        tabelka[1]=2;
        tabelka[2]=3;
        tabelka[3]=4;
        tabelka[4]=5;

       int index = 0;

       while (index<tabelka.length -1) {
            System.out.println(tabelka[index]);
            index++;
       }
    }
}
