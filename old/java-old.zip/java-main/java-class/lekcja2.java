package com.example.basic;

public class lekcja2 {

   public static void main(String[] args) {
       int number =24;
       number=98;
       byte small = -127;
       short numShort = 32000;
       long big = 262748487;

       System.out.println(number);

   }

}
